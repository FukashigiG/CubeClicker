using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeStatus : MonoBehaviour
{
    [SerializeField] int _worth;

    public int Worth => _worth;
}
