using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class CubeBox : MonoBehaviour
{
    [SerializeField] PlayerPresenter _playerPresenter;

    [SerializeField] float magnif_TurnIntoCoin;

    void Start()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent(out CubeStatus _cubeStatus))
        {
            _playerPresenter.GetCoin(_cubeStatus.Worth * magnif_TurnIntoCoin);

            Destroy(collision.gameObject);
        }
    }
}
