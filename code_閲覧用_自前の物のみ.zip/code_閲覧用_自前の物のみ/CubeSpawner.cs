using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeSpawner : MonoBehaviour
{
    [Serializable] class CubesInfo
    {
        public int weight;

        public GameObject cube;
    }

    [SerializeField] CubesInfo[] m_cubes;

    [SerializeField] float range_SpawnPosi;

    void Start()
    {
        
    }

    public void Spawn(float luckBonus)
    {
        Instantiate(LotteryCube(luckBonus), transform.position + new Vector3(UnityEngine.Random.Range(-range_SpawnPosi, range_SpawnPosi), 0f, 0f), Quaternion.Euler(0f, 0f, UnityEngine.Random.Range(0f, 90f)));
    }

    GameObject LotteryCube(float luckBonus)
    {
        int sum_Weight = 0;

        foreach (var member in m_cubes)
        {
            sum_Weight += member.weight;
        }

        int x = UnityEngine.Random.Range(0, sum_Weight);

        int randomNum = (int)(x * (1 + luckBonus));

        if (randomNum > sum_Weight) randomNum = sum_Weight;

        for (int i = 0; i < m_cubes.Length; i++)
        {
            if(randomNum <= m_cubes[i].weight)
            {
                return m_cubes[i].cube;
            }
            else
            {
                randomNum -= m_cubes[i].weight;
            }
        }

        return m_cubes[0].cube;

    }
}
