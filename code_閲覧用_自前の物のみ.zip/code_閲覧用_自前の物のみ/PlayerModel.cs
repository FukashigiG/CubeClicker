using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerModel
{
    DataService _dataService;
    TableStyle_Player data;

    //�ȉ�3�͕s���p�����[�^

    public float IF_TapPower { get; private set; } = 0.15f;
    public float IF_Luck { get; private set; } = 0.015f;
    public float IF_TurnInto { get; private set; } = 0.05f;

    //�ȉ�4�͕ϓ��p�����[�^

    public int amount_Coin {  get; private set; }
    public int Lv_TapPower {  get; private set; }
    public int Lv_Luck {  get; private set; }
    public int Lv_TurnInto {  get; private set; }

    public enum propertyEnum
    {
        coin, tapPower, luck, turnIntoCoin
    }

    public PlayerModel(int id_toLoad)
    {
        _dataService = new DataService("data.db");

        data = _dataService.GetInfo(id_toLoad);

        amount_Coin = data.Coin;

        Lv_TapPower = data.Lv_TapPower;
        Lv_Luck = data.Lv_Luck;
        Lv_TurnInto = data.Lv_TurnIntoMoney;
    }

    public void Add(propertyEnum _property, float x)
    {
        switch (_property)
        {
            case propertyEnum.coin:
                amount_Coin += (int)x;
                break;

            case propertyEnum.tapPower:
                Lv_TapPower += (int)x;
                break;

            case propertyEnum.luck:
                Lv_Luck += (int)x;
                break;

            case propertyEnum.turnIntoCoin:
                Lv_TurnInto += (int)x;
                break;
        }
    }

    public void SaveTheData()
    {
        var cullentData = new TableStyle_Player
        {
            Id = data.Id,
            Name = data.Name,
            Coin = amount_Coin,
            Lv_Luck = Lv_Luck,
            Lv_TapPower = Lv_TapPower,
            Lv_TurnIntoMoney = Lv_TurnInto

        };

        _dataService.UpdateData(cullentData);
    }

    public int GetRequiredCoinToLvUp(int cullentLv)
    {
        return (int)Mathf.Pow(cullentLv + 1, 2);
    }
}
