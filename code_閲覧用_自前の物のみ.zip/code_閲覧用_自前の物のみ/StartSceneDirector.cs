using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StartSceneDirector : MonoBehaviour
{
    DataService _dataService;

    public static int cullentId {  get; private set; }

    [SerializeField] GameObject parent_DataButton;
    [SerializeField] GameObject prefab_SavedDataButton;

    private void Awake()
    {
        _dataService = new DataService("data.db");

        LoadExistingData();
    }

    void LoadExistingData()
    {
        List<TableStyle_Player> dataList = _dataService.GetAllInfos();

        foreach (TableStyle_Player player in dataList)
        {
            GameObject theButtonObj = Instantiate(prefab_SavedDataButton, parent_DataButton.transform);

            theButtonObj.TryGetComponent(out LoadDataButtonCtrler component);

            component.SetInfo(player);

            component.Load.AddListener(() => LoadMainScene(player.Id));
            component.DeleteData.AddListener(() => DeleteSaveData(player.Id));
        }
    }

    public void NewUserRegistration(Text _text)
    {
        int newId = _dataService.CreateNewSaveData(_text.text);

        Debug.Log(newId);

        LoadMainScene(newId);
    }

    public void ContinueData()
    {

    }

    void DeleteSaveData(int _id)
    {
        _dataService.DeleteData(_id);

        foreach(Transform button in parent_DataButton.transform)
        {
            Destroy(button.gameObject);
        }

        LoadExistingData();
    }

    void LoadMainScene(int _id)
    {
        cullentId = _id;

        SceneManager.LoadScene("MainScene");
    }

    private void OnDestroy()
    {
        _dataService.CloseConnection();
    }
}
