using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using TMPro;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;

public class PlayerPresenter : MonoBehaviour
{
    [SerializeField] CubeSpawner _cubeSpawner;

    [SerializeField] Text txt_Coin;

    [SerializeField] Image gauge_Tap;

    [SerializeField] float border_TapComplete;

    [Serializable] class StatusButton
    {
        public Text text_Lv;

        public Text text_Amount_Coin_Required;
    }

    [SerializeField] StatusButton S_Button_TapPower;
    [SerializeField] StatusButton S_Button_Luck;
    [SerializeField] StatusButton S_Button_TurnIntoCoin;

    float tapCount;

    PlayerModel _model;

    void Start()
    {
        _model = new PlayerModel(StartSceneDirector.cullentId);

        txt_Coin.text =_model.amount_Coin.ToString();

        tapCount = 0;

        gauge_Tap.fillAmount = tapCount / border_TapComplete;

        S_Button_TapPower.text_Lv.text = "Lv." + _model.Lv_TapPower;
        S_Button_Luck.text_Lv.text = "Lv." + _model.Lv_Luck;
        S_Button_TurnIntoCoin.text_Lv.text = "Lv." + _model.Lv_TurnInto;

        S_Button_TapPower.text_Amount_Coin_Required.text = _model.GetRequiredCoinToLvUp(_model.Lv_TapPower).ToString();
        S_Button_Luck.text_Amount_Coin_Required.text = _model.GetRequiredCoinToLvUp(_model.Lv_Luck).ToString();
        S_Button_TurnIntoCoin.text_Amount_Coin_Required.text = _model.GetRequiredCoinToLvUp(_model.Lv_TurnInto).ToString();
    }

    public void GetCoin(float x)
    {
        _model.Add(PlayerModel.propertyEnum.coin, x * (1 + _model.Lv_TurnInto * _model.IF_TurnInto));

        txt_Coin.text = _model.amount_Coin.ToString();
    }

    public void LvUp_TapPower()
    {
        int x = _model.GetRequiredCoinToLvUp(_model.Lv_TapPower);

        if (_model.amount_Coin < x) return;

        _model.Add(PlayerModel.propertyEnum.tapPower, 1);

        _model.Add(PlayerModel.propertyEnum.coin, -1 * x);

        //�X�V
        x = _model.GetRequiredCoinToLvUp(_model.Lv_TapPower);

        txt_Coin.text = _model.amount_Coin.ToString();
        S_Button_TapPower.text_Lv.text = "Lv." + _model.Lv_TapPower;
        S_Button_TapPower.text_Amount_Coin_Required.text = x.ToString();
    }

    public void LvUp_Luck()
    {
        int x = _model.GetRequiredCoinToLvUp(_model.Lv_Luck);

        if (_model.amount_Coin < x) return;

        _model.Add(PlayerModel.propertyEnum.luck, 1);

        _model.Add(PlayerModel.propertyEnum.coin, -1 * x);

        //�X�V
        x = _model.GetRequiredCoinToLvUp(_model.Lv_Luck);

        txt_Coin.text = _model.amount_Coin.ToString();
        S_Button_Luck.text_Lv.text = "Lv." + _model.Lv_Luck;
        S_Button_Luck.text_Amount_Coin_Required.text = x.ToString();
    }

    public void LvUp_TurnInto()
    {
        int x = _model.GetRequiredCoinToLvUp(_model.Lv_TurnInto);

        if (_model.amount_Coin < x) return;

        _model.Add(PlayerModel.propertyEnum.turnIntoCoin, 1);

        _model.Add(PlayerModel.propertyEnum.coin, -1 * x);

        //�X�V
        x = _model.GetRequiredCoinToLvUp(_model.Lv_TurnInto);

        txt_Coin.text = _model.amount_Coin.ToString();
        S_Button_TurnIntoCoin.text_Lv.text = "Lv." + _model.Lv_TurnInto;
        S_Button_TurnIntoCoin.text_Amount_Coin_Required.text = x.ToString();
    }

    public void OnTap()
    {
        tapCount += 1 + _model.Lv_TapPower * _model.IF_TapPower ;

        if(tapCount >= border_TapComplete)
        {
            while(tapCount >= border_TapComplete)
            {
                _cubeSpawner.Spawn(_model.IF_Luck * _model.Lv_Luck);

                tapCount -= border_TapComplete;
            }
        }

        gauge_Tap.fillAmount = tapCount / border_TapComplete;
    }

    public void Save()
    {
        _model.SaveTheData();
    }

    public void GoToStartScene()
    {
        SceneManager.LoadScene("StartScene");
    }
}
