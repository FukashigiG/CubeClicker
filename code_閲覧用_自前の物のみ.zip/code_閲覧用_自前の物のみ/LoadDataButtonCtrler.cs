using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class LoadDataButtonCtrler : MonoBehaviour
{
    [SerializeField] Button _button_load;
    [SerializeField] Button _button_delete;

    TableStyle_Player info;

    [SerializeField] Text txt_Name;

    public UnityEvent Load = new UnityEvent();
    public UnityEvent DeleteData = new UnityEvent();

    void Start()
    {
        _button_load.onClick.AddListener(() => Load.Invoke());
        _button_delete.onClick.AddListener(() => DeleteData.Invoke());
    }

    public void SetInfo(TableStyle_Player _info)
    {
        info = _info;

        txt_Name.text = info.Name;
    }
}
